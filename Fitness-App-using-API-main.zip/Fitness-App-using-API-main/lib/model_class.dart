class Exercise {
  String? id, title, gif, thumbnail, seconds;

  Exercise({this.id, this.title, this.thumbnail, this.gif, this.seconds});
}
