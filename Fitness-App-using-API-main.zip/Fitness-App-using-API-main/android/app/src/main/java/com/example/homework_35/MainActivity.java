package com.example.homework_35;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
