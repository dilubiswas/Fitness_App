# Fitness-App-using-API

Fitness App using API

# Output
![m1](https://user-images.githubusercontent.com/109650374/205672558-fe490f81-9cfe-4d6c-bfa0-03530c0b58e2.jpeg)
![m2](https://user-images.githubusercontent.com/109650374/205672586-d3474e32-5ccb-47ac-9d49-5338d06a2f3c.jpeg)
![m3](https://user-images.githubusercontent.com/109650374/205672600-2e9fab29-a49b-4089-9b0c-d2817ac7b90f.jpeg)
